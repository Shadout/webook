from fastapi import APIRouter, HTTPException, Request
from models import IncidentData

router = APIRouter()

@router.post("/api/jwt/login")
async def login():
    # Retornar un token simulado
    token = "token_simulado_123456789"
    return {"token": token}

import json  # Importa json para usar json.dumps()

@router.post("/api/arsys/v1/entry/HPD:IncidentInterface_Create")
async def create_incident(data: IncidentData, request: Request):
    # Simular autenticación
    auth_header = request.headers.get("Authorization")
    if auth_header != "AR-JWT token_simulado_123456789":
        raise HTTPException(status_code=401, detail="Token inválido o no proporcionado")

    # Extraer los datos enviados
    incident_values = data.values

    # Usar json.dumps en lugar de incident_values.json()
    print(json.dumps(incident_values.dict(), indent=2, ensure_ascii=False))

    # Simular la creación de la incidencia
    incident_number = "INC000123456789"
    entry_id = "AG005056c0002uCFAAszLUYQAAJYbV"

    # Retornar la respuesta simulada
    return {
        "values": {
            "Incident Number": incident_number,
            "Entry ID": entry_id
        },
        "_links": {
            "self": {"href": f"/api/arsys/v1/entry/HPD:IncidentInterface_Create/{entry_id}"}
        }
    }
