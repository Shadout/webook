from pydantic import BaseModel
from typing import Literal

class IncidentValues(BaseModel):
    Login_ID: str
    Reported_Source: str
    Service_Type: str
    Vendor_Ticket_Number: str
    Categorization_Tier_1: Literal["Incidencia", "Peticion"]
    Product_Categorization_Tier_1: str
    Product_Categorization_Tier_2: str
    Product_Categorization_Tier_3: str
    Description: str
    IBER_ModoCalculoPrioridad: Literal["Manual"]
    IBER_HPD_Temp_Field_1: Literal["BAJA", "MEDIA", "ALTA", "MUY ALTA", "CRITICA"]

class IncidentData(BaseModel):
    values: IncidentValues
